function attachEvents() {
    const url = `http://localhost:3030/jsonstore/phonebook`;
    const container = document.getElementById("phonebook");
    document.getElementById("btnLoad").addEventListener("click", onLoadInfo);
    document.getElementById("btnCreate").addEventListener("click", onCreate);
  
    async function onCreate() {
      const person = document.getElementById("person");
      const phone = document.getElementById("phone");
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          person: person.value,
          phone: phone.value,
        }),
      });
      document.getElementById("btnLoad").click();
      person.value = "";
      phone.value = "";
    }
  
    async function onLoadInfo() {
      container.innerHTML = "";
      const response = await fetch(url);
      const data = await response.json();
      for (const phoneNumber of Object.values(data)) {
        const li = document.createElement("li");
        const deleteBtn = document.createElement("button");
        deleteBtn.textContent = "Delete";
        deleteBtn.addEventListener("click", onDelete);
  
        li.textContent = `${phoneNumber.person}: ${phoneNumber.phone}`;
        li.setAttribute("id", phoneNumber._id);
  
        li.appendChild(deleteBtn);
        container.appendChild(li);
      }
    }
    async function onDelete(e) {
      const id = e.target.parentElement.id;
      e.target.parentElement.remove();
  
      const response = await fetch(`${url}/${id}`, {
        method: "delete",
      });
    }
  }
  
attachEvents();


//   function attachEvents() {
//     document.getElementById('btnLoad').addEventListener('click', onLoadAllRecords);
//     document.getElementById('btnCreate').addEventListener('click', handleCreateRecord)
// }

// function handleCreateRecord() {
//     const personEl = document.getElementById('person');
//     const phoneEl = document.getElementById('phone');

//     onCreateRecord(personEl.value, phoneEl.value);
//     personEl.value = '';
//     phoneEl.value = '';
// }

// function renderRecord(data){
//     const ul = document.getElementById('phonebook');
//     ul.innerHTML = '';
//     Object.values(data).forEach(rec => {
//        const li = document.createElement('li');
//        li.textContent = `${rec.person}: ${rec.phone}`;
//        li.setAttribute('data-id', rec._id);
       
//        const btn = document.createElement('button');
//        btn.textContent = 'Delete';
//        btn.addEventListener('click', handleDelete);
//        li.appendChild(btn);
//        ul.appendChild(li);
//    })
// }

// function handleDelete(e) {
//     const li = e.target.parentElement;
//     const id = li.getAttribute('data-id');
//     onDeleteRecords(id);
//     li.remove();
// }

// async function onLoadAllRecords() {
//     const url = 'http://localhost:3030/jsonstore/phonebook';
//     const response = await fetch(url);
//     const data = await response.json();

//     return renderRecord(data);
// }

// async function onCreateRecord(person, phone) {
//     const url = 'http://localhost:3030/jsonstore/phonebook';
//     const body = {
//         person,
//         phone
//     }
//     const header = getHeader('POST', body);
//     const response = await fetch(url, header);

//     const data = await response.json();
//     onLoadAllRecords();
//     return data;
// }

// async function onDeleteRecords(id){
//     const url = `http://localhost:3030/jsonstore/phonebook/${id}`;

//     const headers = getHeader('DELETE', null);
//     const response = await fetch(url, headers);
//     const data = await response.json();
//     return data;
// }

// function getHeader (method, body) {
//     return {
//         method: `${method}`,
//         headers: {
//             "Content-Type": "application/json"
//         },
//         body: JSON.stringify(body)
//     }
// }

// attachEvents();