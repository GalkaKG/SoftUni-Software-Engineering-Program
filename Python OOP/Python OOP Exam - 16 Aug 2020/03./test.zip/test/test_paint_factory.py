from project.factory.paint_factory import PaintFactory

# from testing.project.factory.paint_factory import PaintFactory
from unittest import TestCase


class PaintFactoryTests(TestCase):
    def setUp(self) -> None:
        self.paint_factory = PaintFactory("Factory", 20)

    def test_init_proper_initialization(self):
        self.assertEqual("Factory", self.paint_factory.name)
        self.assertEqual(20, self.paint_factory.capacity)
        self.assertEqual(["white", "yellow", "blue", "green", "red"], self.paint_factory.valid_ingredients)
        self.assertEqual({}, self.paint_factory.ingredients)

    def test_can_add_if_enough_capacity(self):
        self.paint_factory.add_ingredient("white", 10)
        result = self.paint_factory.can_add(10)
        self.assertEqual(True, result)

    def test_can_add_if_not_enough_capacity(self):
        self.paint_factory.add_ingredient("white", 15)
        result = self.paint_factory.can_add(10)
        self.assertEqual(False, result)

    def test_add_ingredient_not_enough_capacity_raise_error(self):
        self.paint_factory.add_ingredient("white", 15)

        with self.assertRaises(ValueError) as error:
            self.paint_factory.add_ingredient("white", 10)

        self.assertEqual("Not enough space in factory", str(error.exception))

    def test_add_ingredient_if_invalid_type_raise_error(self):
        with self.assertRaises(TypeError) as error:
            self.paint_factory.add_ingredient("asd", 10)

        self.assertEqual(f"Ingredient of type asd not allowed in PaintFactory", str(error.exception))

    def test_add_ingredient_product_add_quantity_successfully(self):
        self.paint_factory.add_ingredient("white", 5)
        self.assertEqual({"white": 5}, self.paint_factory.ingredients)

        self.paint_factory.add_ingredient("white", 5)
        self.assertEqual({"white": 10}, self.paint_factory.ingredients)

        self.paint_factory.add_ingredient("blue", 5)
        self.assertEqual({"white": 10, "blue": 5}, self.paint_factory.ingredients)

    def test_remove_ingredient_removing_invalid_quantity_raise_error(self):
        self.paint_factory.add_ingredient("white", 5)

        with self.assertRaises(ValueError) as error:
            self.paint_factory.remove_ingredient("white", 10)

        self.assertEqual("Ingredients quantity cannot be less than zero", str(error.exception))

    def test_remove_ingredient_no_such_ingredient_raise_error(self):
        with self.assertRaises(KeyError) as error:
            self.paint_factory.remove_ingredient("blue", 5)

        self.assertEqual("'No such ingredient in the factory'", str(error.exception))

    def test_remove_ingredient_successfully(self):
        self.paint_factory.add_ingredient("white", 10)
        self.paint_factory.remove_ingredient("white", 5)

        self.assertEqual({"white": 5}, self.paint_factory.ingredients)

        self.paint_factory.remove_ingredient("white", 5)
        self.assertEqual({"white": 0}, self.paint_factory.ingredients)

    def test_repr_correct_output(self):
        self.paint_factory.add_ingredient("white", 10)
        self.paint_factory.add_ingredient("blue", 10)

        result = f"Factory name: Factory with capacity 20.\nwhite: 10\nblue: 10\n"

        self.assertEqual(result, self.paint_factory.__repr__())

    def test_repr_if_not_ingredients(self):
        result = f"Factory name: Factory with capacity 20.\n"

        self.assertEqual(result, self.paint_factory.__repr__())

    def test_products_property_if_returns_ingredients(self):
        self.assertEqual( self.paint_factory.products, self.paint_factory.ingredients)
