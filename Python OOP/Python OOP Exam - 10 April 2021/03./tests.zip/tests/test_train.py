# from testing.project.train.train import Train

from project.train.train import Train

from unittest import TestCase


class TrainTests(TestCase):
    def setUp(self) -> None:
        self.train = Train("Express", 5)

    def test_init_if_its_correct(self):
        self.assertEqual("Express", self.train.name)
        self.assertEqual(5, self.train.capacity)
        self.assertEqual([], self.train.passengers)

    def test_class_attributes_are_proper(self):
        self.assertEqual("Train is full", Train.TRAIN_FULL)
        self.assertEqual("Passenger {} Exists", Train.PASSENGER_EXISTS)
        self.assertEqual("Passenger Not Found", Train.PASSENGER_NOT_FOUND)
        self.assertEqual("Added passenger {}", Train.PASSENGER_ADD)
        self.assertEqual("Removed {}", Train.PASSENGER_REMOVED)
        self.assertEqual(0, Train.ZERO_CAPACITY)

    def test_add_when_capacity_is_full_raise_error(self):
        self.train.passengers = ["a", "b", "c", "d", "e"]

        with self.assertRaises(ValueError) as error:
            self.train.add("f")

        self.assertEqual(self.train.TRAIN_FULL, str(error.exception))

    def test_add_when_passenger_already_exist_raise_error(self):
        passenger_name = " Ivan"
        self.train.passengers = [passenger_name]

        with self.assertRaises(ValueError) as error:
            self.train.add(passenger_name)

        self.assertEqual(f"Passenger {passenger_name} Exists", str(error.exception))

    def test_add_passenger_successfully(self):
        passenger_name = " Ivan"
        result = self.train.add(passenger_name)

        self.assertEqual(f"Added passenger {passenger_name}", result)

    def test_remove_passenger_name_if_not_exist_raise_error(self):
        passenger_name = " Ivan"

        with self.assertRaises(ValueError) as error:
            self.train.remove(passenger_name)

        self.assertEqual("Passenger Not Found", str(error.exception))

    def test_remove_successfully_removed_passenger(self):
        passenger_name = " Ivan"
        self.train.add(passenger_name)

        result = self.train.remove(passenger_name)

        self.assertEqual(f"Removed {passenger_name}", result)