from project.library import Library

# from testing.library import Library
from unittest import TestCase


class LibraryTests(TestCase):
    reader_name = "Ivan"
    book_author = "Hristo Botev"
    book_title = "Book"

    def setUp(self) -> None:
        self.library = Library("Library")

    def test_init(self):
        self.assertEqual("Library", self.library.name)
        self.assertEqual({}, self.library.books_by_authors)
        self.assertEqual({}, self.library.readers)

    def test_name_if_is_empty_string_raise_error(self):
        with self.assertRaises(ValueError) as error:
            self.library.name = ''

        self.assertEqual("Name cannot be empty string!", str(error.exception))

    def test_add_book_if_author_not_in_books_by_authors(self):
        self.library.add_book("Ivan", "Story")
        self.assertEqual({"Ivan": ["Story"]}, self.library.books_by_authors)

    def test_add_book_add_book_name_to_author(self):
        self.library.add_book("Ivan", "Story")
        self.library.add_book("Ivan", "Second")
        self.assertEqual({"Ivan": ["Story", "Second"]}, self.library.books_by_authors)

    def test_add_reader_name_not_registered_and_register_it(self):
        self.library.add_reader("Ivan")
        self.assertEqual({"Ivan": []}, self.library.readers)

    def test_add_reader_name_already_registered_raise_error(self):
        self.library.add_reader("Ivan")
        result = self.library.add_reader("Ivan")

        self.assertEqual(f"Ivan is already registered in the {self.library.name} library.", result)

    def test_rent_book_reader_not_exist(self):
        result = self.library.rent_book(self.reader_name, self.book_author, self.book_title)

        self.assertEqual(f"{self.reader_name} is not registered in the {self.library.name} Library.", result)

    def test_rent_book_reader_book_author_not_exist(self):
        self.library.add_reader(self.reader_name)

        result = self.library.rent_book(self.reader_name, self.book_author, self.book_title)

        self.assertEqual(f"{self.library.name} Library does not have any {self.book_author}'s books.", result)

    def test_rent_book_book_title_not_exist(self):
        self.library.add_reader(self.reader_name)
        self.library.add_book(self.book_author, self.book_title)

        result = self.library.rent_book(self.reader_name, self.book_author, "NotExist")

        self.assertEqual(f"""{self.library.name} Library does not have {self.book_author}'s "NotExist".""", result)

    def test_rent_book_remove_book_from_library_books_by_authors_and_give_the_book_to_reader(self):
        self.library.add_reader(self.reader_name)
        self.library.add_book(self.book_author, self.book_title)

        self.library.rent_book(self.reader_name, self.book_author, self.book_title)
        expected = {self.reader_name: [{self.book_author: self.book_title}]}

        self.assertEqual(expected, self.library.readers)
        self.assertEqual({self.book_author: []}, self.library.books_by_authors)




