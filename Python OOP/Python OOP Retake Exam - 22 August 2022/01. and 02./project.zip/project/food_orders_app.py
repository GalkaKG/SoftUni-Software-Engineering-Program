from project.meals.meal import Meal
from project.client import Client


class FoodOrdersApp:
    receipt_id = 0

    def __init__(self):
        self.menu = []
        self.clients_list = []

    def _find_client(self, client_phone_number):
        for client in self.clients_list:
            if client.phone_number == client_phone_number:
                return client

    def _check_the_menu_if_is_ready(self):
        if len(self.menu) < 5:
            raise Exception("The menu is not ready!")

    @staticmethod
    def _check_if_the_client_shopping_cart_is_empty(client):
        if not client.shopping_cart:
            raise Exception("There are no ordered meals!")

    def register_client(self, client_phone_number: str):
        client = self._find_client(client_phone_number)
        if client:
            raise Exception("The client has already been registered!")
        self.clients_list.append(Client(client_phone_number))

        return f"Client {client_phone_number} registered successfully."

    def add_meals_to_menu(self, *meals: Meal):
        for meal in meals:
            if meal.__class__.__name__ in ["Starter", "MainDish", "Dessert"]:
                self.menu.append(meal)

    def show_menu(self):
        self._check_the_menu_if_is_ready()

        result = ''
        for meal in self.menu:
            result += meal.details() + '\n'

        return result.strip()

    def add_meals_to_shopping_cart(self, client_phone_number: str, **meal_names_and_quantities):
        self._check_the_menu_if_is_ready()

        if not self._find_client(client_phone_number):
            self.register_client(client_phone_number)

        client = self._find_client(client_phone_number)
        self.clients_list.append(client)

        meals_to_order = []
        bill = 0

        for meal_name, meal_quantity in meal_names_and_quantities.items():
            for meal in self.menu:
                if meal.name == meal_name:
                    if meal.quantity >= meal_quantity:
                        meals_to_order.append(meal)
                        bill += meal.price * meal_quantity
                        break
                    else:
                        raise Exception(f"Not enough quantity of {type(meal).__name__}: {meal_name}!")
            else:
                raise Exception(f"{meal_name} is not on the menu!")

        client.bill += bill
        client.shopping_cart.extend(meals_to_order)

        for meal_name, meal_quantity in meal_names_and_quantities.items():
            client.ordered_meals[meal_name] = meal_quantity
            for meal in self.menu:
                if meal.name == meal_name:
                    meal.quantity -= meal_quantity

        return f"Client {client_phone_number} " \
               f"successfully ordered {', '.join([f.name for f in client.shopping_cart])} " \
               f"for {client.bill:.2f}lv."

    def cancel_order(self, client_phone_number: str):
        client = self._find_client(client_phone_number)

        self._check_if_the_client_shopping_cart_is_empty(client)

        for cancel_meal, quantity in client.ordered_meals.items():
            for meal in self.menu:
                if cancel_meal == meal.name:
                    meal.quantity += quantity

        client.shopping_cart.clear()
        client.bill = 0
        client.ordered_meals = {}

        return f"Client {client_phone_number} successfully canceled his order."

    def finish_order(self, client_phone_number: str):
        client = self._find_client(client_phone_number)

        self._check_if_the_client_shopping_cart_is_empty(client)

        client.shopping_cart.clear()
        client.ordered_meals = {}
        total_paid_money = client.bill
        client.bill = 0
        FoodOrdersApp.receipt_id += 1

        return f"Receipt #{FoodOrdersApp.receipt_id} with total amount of {total_paid_money:.2f} " \
               f"was successfully paid for {client_phone_number}."

    def __str__(self):
        return f"Food Orders App has {len(self.menu)} meals on the menu and {len(self.clients_list)} clients."
