from unittest import TestCase
from project.movie import Movie
# from testing.movie import Movie


class MovieTests(TestCase):
    def setUp(self) -> None:
        self.movie = Movie("Matrix", 2000, 10)

    def test_init(self):
        self.assertEqual("Matrix", self.movie.name)
        self.assertEqual(2000, self.movie.year)
        self.assertEqual(10, self.movie.rating)
        self.assertEqual([], self.movie.actors)

    def test_name_empty_string_raise_error(self):
        with self.assertRaises(ValueError) as error:
            self.movie.name = ''

        self.assertEqual("Name cannot be an empty string!", str(error.exception))

    def test_year_is_invalid_raises_error(self):
        with self.assertRaises(ValueError) as error:
            self.movie.year = 1886

        self.assertEqual("Year is not valid!", str(error.exception))

    def test_add_actor_if_does_not_exist_in_actors_list(self):
        name = "Keanu Reeves"

        self.movie.add_actor(name)

        self.assertEqual([name], self.movie.actors)

    def test_add_actor_if_actor_exist(self):
        name = "Keanu Reeves"
        self.movie.add_actor(name)

        result = self.movie.add_actor(name)

        self.assertEqual(f"{name} is already added in the list of actors!", result)

    def test_gt_self_is_better_than_other(self):
        other = Movie("Need for speed", 2006, 8)

        result = self.movie.__gt__(other)

        self.assertEqual(f'"{self.movie.name}" is better than "{other.name}"', result)

    def test_gt_other_is_better_than_self(self):
        other = Movie("Need for speed", 2006, 15)

        result = self.movie.__gt__(other)

        self.assertEqual(f'"{other.name}" is better than "{self.movie.name}"', result)

    def test_repr_with_actors(self):
        self.movie.add_actor("Keanu Reeves")
        self.movie.add_actor("Carrie-Anne Moss")

        expected = f"Name: {self.movie.name}\n" \
                   f"Year of Release: {self.movie.year}\n" \
                   f"Rating: {self.movie.rating:.2f}\n" \
                   f"Cast: {', '.join(self.movie.actors)}"

        self.assertEqual(expected, self.movie.__repr__())

    def test_repr_without_actors(self):

        expected = f"Name: {self.movie.name}\n" \
                   f"Year of Release: {self.movie.year}\n" \
                   f"Rating: {self.movie.rating:.2f}\n" \
                   f"Cast: "

        self.assertEqual(expected, self.movie.__repr__())